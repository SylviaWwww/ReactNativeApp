// ProjectTrackingContext.jsx

import React, { createContext, useState, useEffect, useContext } from "react";
import { getUserTracking } from "../api/TrackingApi";
import { UsernameContext } from "./UsernameContext";

// Making sure Tracking data can be used in Map, Scanner, and ProjectHome
export const ProjectTrackingContext = createContext();

export const ProjectTrackingProvider = ({ children, projectId }) => {
  const [visitedLocations, setVisitedLocations] = useState([]); // Array of location IDs
  const [totalPoints, setTotalPoints] = useState(0);
  const [triggeredLocation, setTriggeredLocation] = useState(null); // Used to track and generate related location content, as well as the participant number.

  const { username } = useContext(UsernameContext);

  // Fetch user's tracking data whenever participant_username or projectId changes
  useEffect(() => {
    async function fetchUserTracking() {
      try {
        if (username) {
          const trackingData = await getUserTracking(
            projectId.projectId,
            username
          );
          const visitedLocationIds = trackingData.map(
            (record) => record.location_id
          );
          const totalPointsEarned = trackingData.reduce(
            (sum, record) => sum + record.points,
            0
          );
          setVisitedLocations(visitedLocationIds);
          setTotalPoints(totalPointsEarned);
        } else {
          // If username is not set, reset tracking data
          setVisitedLocations([]);
          setTotalPoints(0);
        }
      } catch (error) {
        console.error("Error fetching user tracking data:", error);
      }
    }
    fetchUserTracking();
  }, [projectId, username]);

  return (
    <ProjectTrackingContext.Provider
      value={{
        visitedLocations,
        setVisitedLocations,
        totalPoints,
        setTotalPoints,
        triggeredLocation,
        setTriggeredLocation,
      }}
    >
      {/* ProjectHome, MapPage, ScannerPage - make sure these pages could get tracking data through `children`. */}
      {children}
    </ProjectTrackingContext.Provider>
  );
};
