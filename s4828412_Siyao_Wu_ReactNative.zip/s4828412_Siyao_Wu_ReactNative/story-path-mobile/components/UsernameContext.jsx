import { createContext } from 'react';
// Create a Context object, export it so that other components can import and use it.

export const UsernameContext = createContext({
  username: '',
  setUsername: () => {},
});
