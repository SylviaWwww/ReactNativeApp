// CustomDrawerContent.jsx

import React, { useContext } from "react";
import { View, Text, StyleSheet, SafeAreaView } from "react-native";
import {
  DrawerContentScrollView,
  DrawerItemList,
} from "@react-navigation/drawer";
import { SvgXml } from "react-native-svg";

import { UsernameContext } from "./UsernameContext";

const CustomDrawerContent = (props) => {
  // Get Drawer Content like "Welcome" from AppNavigator.js
  const { username } = useContext(UsernameContext);

  // SVG usage method is generated from chatgpt
  const svgXmlData = `<?xml version="1.0" ?><!DOCTYPE svg  PUBLIC '-//W3C//DTD SVG 1.1//EN'  'http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd'><svg height="128px" id="Layer_1" style="enable-background:new 0 0 128 128;" version="1.1" viewBox="0 0 128 128" width="128px" xml:space="preserve" xmlns="http://www.w3.org/2000/svg"><style type="text/css">
    <![CDATA[
    	.st0{fill-rule:evenodd;clip-rule:evenodd;}
    ]]>
    </style><path d="M107.376,30.46C91.782,11.858,60.128,8.291,38.058,17.024C24.805,22.275,15.802,32.388,13.287,46.01  c-1.544,8.371-0.957,17.496,2.735,25.311c0.824,1.736,1.811,3.41,2.985,4.956c0.569,0.754,1.18,1.475,1.844,2.16  c1.175-0.42,2.311-0.943,3.395-1.556c4.479-2.529,7.785-6.426,11.621-9.698c-12.824-14.857,0.766-33.265,17.766-37.37  c15.827-3.815,37.276,2.77,42.075,19.053c1.985,6.744,0.686,14.2-4.814,19.082c-2.875,2.556-6.526,4.244-10.385,4.932  c-2.254,0.4-4.568,0.462-6.847,0.239c-1.271-0.128-2.532-0.343-3.774-0.635c-2.104-0.497-3.978-0.423-3.978-2.693  c0-5.932,0-11.868,0-17.803c0-2.964,0-5.934,0-8.903c0-1.819,0.178-1.476-1.331-1.664c-1.192-0.147-2.381-0.263-3.574-0.356  c-4.199-0.329-8.588-0.555-12.753,0.163c-1.558,0.27-1.657,0.018-1.657,1.708c0,1.369,0,2.737,0,4.101c0,3.327,0,6.654,0,9.981  c0,9.942,0.749,20.003,0.339,29.93c-0.12,2.959-0.202,10.058-3.513,11.523c-3.836,1.697-7.23-1.893-10.771-2.64  c0.487,4.984-2.631,14.857,3.179,17.373c5.327,2.306,11.456,3.165,17.071,1.26c11.765-3.99,15.569-17.083,14.079-27.842  c18.161,5.428,37.763-3.652,45.529-20.051C118.038,54.894,115.702,40.39,107.376,30.46z"/></svg>`;

  // if user doesn't enter username, show "visitor(No Username)"
  const displayName =
    username && username.trim() !== "" ? username : "visitor(No Username)";

  return (
    <DrawerContentScrollView
      {...props} // Pass in all props received from the parent component, AppNavigator.js
      contentContainerStyle={styles.container}
    >
      <SafeAreaView style={styles.safeArea}>
        {/* logo area */}
        <View style={styles.header}>
          <SvgXml xml={svgXmlData} width={24} height={24} />
          <Text style={styles.appName}>StoryPath</Text>
        </View>

        {/* seperator line */}
        <View style={styles.separator} />

        {/* Hi, ... */}
        <Text style={styles.greeting}>Hi, {displayName}!</Text>

        {/* seperator line */}
        <View style={styles.separator} />

        {/* title list */}
        <DrawerItemList {...props} />
      </SafeAreaView>
    </DrawerContentScrollView>
  );
};

export default CustomDrawerContent;

// Color generated from https://www.realtimecolors.com/?colors=0c1c0e-f2f9f2-709585-adb7c3-979bb2&fonts=Inter-Inter
const colors = {
  text: "#0b0e0d",
  background: "#fbfcfc",
  primary: "#709585",
  secondary: "#adb7c3",
  accent: "#979bb2",
};

const styles = StyleSheet.create({
  safeArea: {
    backgroundColor: "#fbfcfc",
  },
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingTop: 0,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
  },
  appName: {
    fontSize: 20,
    fontWeight: "bold",
    color: colors.text,
    marginLeft: 8,
  },
  separator: {
    height: 1,
    backgroundColor: colors.accent,
    marginHorizontal: 16,
    marginVertical: 8,
  },
  greeting: {
    fontSize: 20,
    fontWeight: "bold",
    color: colors.text,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
});
