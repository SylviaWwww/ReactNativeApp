// ProjectsPage.jsx

import React, { useEffect, useState, useContext } from "react";
import {
  SafeAreaView,
  View,
  Text,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  TouchableOpacity,
  Alert,
} from "react-native";
import Feather from "react-native-vector-icons/Feather";

import {
  getPublishedProjects,
  getProjectParticipantsCount,
} from "../api/ProjectApi";
import { UsernameContext } from "../components/UsernameContext";

export default function ProjectsPage({ navigation }) {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const { username } = useContext(UsernameContext);

  useEffect(() => {
    async function fetchProjects() {
      try {
        const publishedProjects = await getPublishedProjects();
        const projectsWithParticipants = await Promise.all(
          publishedProjects.map(async (project) => {
            const participantCount = await getProjectParticipantsCount(
              project.id
            );
            return { ...project, participantCount };
          })
        );
        setProjects(projectsWithParticipants);
      } catch (error) {
        alert(`Error fetching projects: ${error.message}`);
      } finally {
        setLoading(false);
      }
    }

    fetchProjects();
  }, []);

  // Function to handle clicking a project
  async function handleProjectClick(projectId) {
    if (!username) {
      Alert.alert(
        "Error",
        "Please enter a username in the profile page before proceeding."
      );
    } else {
      const publishedProjects = await getPublishedProjects();
      const projectsWithParticipants = await Promise.all(
        publishedProjects.map(async (project) => {
          const participantCount = await getProjectParticipantsCount(
            project.id
          );
          return { ...project, participantCount };
        })
      );
      // If user unloack a location, participant number change
      setProjects(projectsWithParticipants);
      navigation.navigate("ProjectHome", { projectId });
    }
  }

  const renderItem = ({ item }) => (
    <TouchableOpacity onPress={() => handleProjectClick(item.id)}>
      <View style={styles.projectCard}>
        <View style={styles.leftContent}>
          <Text style={styles.projectTitle}>{item.title}</Text>
          <Text style={styles.projectDescription}>{item.description}</Text>
          <Text style={styles.projectParticipants}>
            Participants: {item.participantCount}
          </Text>
        </View>
        <View>
          <Feather name="chevrons-right" color={"#0b0e0d"} size={28} />
        </View>
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <SafeAreaView style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0000ff" />
      </SafeAreaView>
    );
  }

  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.container}>
        <Text style={styles.welcomeText}>
          Welcome, {username || "No Username"}
        </Text>
        <FlatList
          data={projects}
          renderItem={renderItem}
          keyExtractor={(item) => item.id.toString()}
        />
      </SafeAreaView>
    </View>
  );
}

// Styles for the ProjectsPage
const styles = {
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#f0f0f0",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  projectCard: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    elevation: 3,
  },
  leftContent: {
    width: '80%',
  },
  projectTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 5,
  },
  projectDescription: {
    fontSize: 16,
    color: "#666",
    marginBottom: 10,
  },
  projectParticipants: {
    fontSize: 14,
    color: "#333",
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 30,
  },
};
