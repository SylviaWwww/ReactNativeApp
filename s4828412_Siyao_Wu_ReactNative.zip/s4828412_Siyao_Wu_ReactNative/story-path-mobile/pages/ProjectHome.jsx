import React, { useEffect, useState, useContext } from "react";
import {
  SafeAreaView,
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  ScrollView,
  useWindowDimensions,
} from "react-native";
import AutoHeightWebView from "react-native-autoheight-webview";

import { getProject, getLocationsByProject } from "../api/ProjectApi";
import { getLocationParticipantsCount } from "../api/TrackingApi";

import { ProjectTrackingContext } from "../components/ProjectTrackingContext";

export default function ProjectHome({ route }) {
  const { projectId } = route.params;
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [totalPointsAvailable, setTotalPointsAvailable] = useState(0);
  const [locations, setLocations] = useState(null);
  const [totalLocations, setTotalLocations] = useState(0);
  const [locationParticipantsCount, setLocationParticipantsCount] = useState(0);

  const {
    visitedLocations,
    totalPoints,
    triggeredLocation,
    setTriggeredLocation,
  } = useContext(ProjectTrackingContext);

  const { width } = useWindowDimensions();

  useEffect(() => {
    async function fetchProject() {
      try {
        const projectData = await getProject(projectId);
        const locationsData = await getLocationsByProject(projectId);
        setLocations(locationsData);
        setProject(projectData);
      } catch (error) {
        alert(`Error fetching project details: ${error.message}`);
      } finally {
        setLoading(false);
      }
    }

    fetchProject();
  }, [projectId]);

  // Fetch total points available and total locations whenever visitedLocations change
  useEffect(() => {
    async function fetchTotalPointsAndLocations() {
      try {
        const locationsData = await getLocationsByProject(projectId);
        const totalPoints = locationsData.reduce(
          (sum, loc) => sum + loc.score_points,
          0
        );
        setTotalPointsAvailable(totalPoints);
        setTotalLocations(locationsData.length);
      } catch (error) {
        console.error("Error fetching total points and locations:", error);
      }
    }

    fetchTotalPointsAndLocations();
  }, [projectId, visitedLocations]);

  // Fetch participants count when triggeredLocation changes
  useEffect(() => {
    if (triggeredLocation) {
      async function fetchParticipantsCount() {
        try {
          const count = await getLocationParticipantsCount(
            triggeredLocation.id
          );
          setLocationParticipantsCount(count);
        } catch (error) {
          console.error("Error fetching location participants count:", error);
        }
      }
      fetchParticipantsCount();
    }
  }, [triggeredLocation]);

  if (loading) {
    return (
      <SafeAreaView style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0000ff" />
      </SafeAreaView>
    );
  }

  if (!project) {
    return (
      <SafeAreaView style={styles.loadingContainer}>
        <Text>Error loading project details.</Text>
      </SafeAreaView>
    );
  }

  const { title, instructions, homescreen_display, initial_clue } = project[0];

  function CustomAutoHeightWebView({ htmlContent }) {
    const { width } = useWindowDimensions();

    return (
      // the style usage is helped with chatgpt
      <AutoHeightWebView
        style={{ width: width - 40 }}
        customStyle={`
          * { font-size: 16px; box-sizing: border-box; }
          img, video { max-width: 100%; height: auto; display: block; }
          p { margin: 0; padding: 0 0 10px 0; }
        `}
        source={{ html: htmlContent }}
        scalesPageToFit={false}
        viewportContent={"width=device-width, user-scalable=no"}
        scrollEnabled={false}
        onSizeUpdated={(size) => {
          console.log("WebView content height:", size.height);
        }}
      />
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.titleBox}>
          <Text style={styles.title}>{title}</Text>
        </View>
        <View style={styles.cardContainer}>
          {/* If location is triggered: */}
          {triggeredLocation ? (
            <>
              {/* Triggered location content*/}
              <View style={styles.SecondaryBox}>
                <Text style={styles.locationName}>
                  {triggeredLocation.location_name}
                </Text>
              </View>
              <View>
                <Text style={styles.locationNumber}>
                  Participants who have unlocked this location:{" "}
                  {locationParticipantsCount}
                </Text>
              </View>
              <Text style={styles.clueTitle}>Content</Text>
              <CustomAutoHeightWebView
                webviewId="location_content"
                htmlContent={triggeredLocation.location_content}
              />
              <Text style={styles.clueTitle}>Clue</Text>
              <CustomAutoHeightWebView
                webviewId="clue"
                htmlContent={triggeredLocation.clue}
              />
            </>
          ) : (
            <>
              {/* The Project Home Page */}
              <Text style={styles.instructionsTitle}>Instructions</Text>
              <CustomAutoHeightWebView
                webviewId="instructions"
                htmlContent={instructions}
              />
              {/* Initial Clue */}
              {homescreen_display === "Display initial clue" ? (
                <>
                  <Text style={styles.initialClueTitle}>Initial Clue</Text>
                  <CustomAutoHeightWebView
                    webviewId="initial_clue"
                    htmlContent={initial_clue}
                  />
                </>
              ) : homescreen_display === "Display all locations" ? (
                <>
                  {/* Location List */}
                  <Text style={styles.initialClueTitle}>Locations List</Text>
                  {locations.map((location) => (
                    <Text style={styles.locationNameStyle} key={location.id}>
                      - {location.location_name}
                    </Text>
                  ))}
                </>
              ) : null}
            </>
          )}

          <View style={styles.bottomContainer}>
            <View style={styles.box}>
              <Text style={styles.boxTitle}>Points</Text>
              <Text style={styles.boxValue}>
                {totalPoints} / {totalPointsAvailable}
              </Text>
            </View>
            <View style={styles.box}>
              <Text style={styles.boxTitle}>Locations Visited</Text>
              <Text style={styles.boxValue}>
                {visitedLocations.length} / {totalLocations}
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f0f0f0",
  },
  scrollContainer: {
    alignItems: "center",
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  titleBox: {
    width: "100%",
    height: 80,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#709585",
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#fff",
  },
  cardContainer: {
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 15,
    elevation: 5,
    width: "100%",
  },
  instructionsTitle: {
    fontSize: 25,
    fontWeight: "bold",
    marginBottom: 10,
  },
  initialClueTitle: {
    fontSize: 25,
    fontWeight: "bold",
    marginTop: 20,
    marginBottom: 5,
  },
  locationNameStyle: {
    fontSize: 16,
    marginBottom: 5,
  },
  waitingText: {
    fontSize: 18,
    color: "#666",
    marginBottom: 15,
  },
  bottomContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
  },
  box: {
    backgroundColor: "#adb7c3",
    paddingVertical: 20,
    paddingHorizontal: 25,
    borderRadius: 10,
    alignItems: "center",
    width: "48%",
  },
  boxTitle: {
    fontSize: 18,
    color: "#fff",
  },
  boxValue: {
    fontSize: 24,
    color: "#fff",
    fontWeight: "bold",
  },
  locationName: {
    fontSize: 28,
    fontWeight: "bold",
  },
  clueTitle: {
    fontSize: 24,
    fontWeight: "bold",
    marginTop: 20,
    marginBottom: 10,
  },
  SecondaryBox: {
    backgroundColor: "#adb7c3",
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: 10,
    alignItems: "center",
    width: "100%",
    marginBottom: 20,
  },
  locationNumber: {
    marginBottom: 20,
  },
});
