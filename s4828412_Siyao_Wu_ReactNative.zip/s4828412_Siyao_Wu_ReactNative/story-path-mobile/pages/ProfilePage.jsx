import React, { useState, useContext } from "react";
import {
  SafeAreaView,
  View,
  Image,
  Dimensions,
  TextInput,
  StyleSheet,
  Text,
  TouchableOpacity,
  ImageBackgroundBase,
} from "react-native";
import * as ImagePicker from "expo-image-picker";

import { UsernameContext } from "../components/UsernameContext";

// Get the screen width and height for styling
const { width } = Dimensions.get("window");

export default function ProfilePage() {
  const { username, setUsername } = useContext(UsernameContext);
  const [photoState, setPhotoState] = useState({});

  // Imagepicker usage referenced from contact week 12
  // Function to handle photo selection using the Image Picker
  async function handleChangePress() {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      setPhotoState(result.assets[0]);
    }
  }

  // Check if a photo has been selected
  const hasPhoto = Boolean(photoState.uri);

  function Photo() {
    return (
      <TouchableOpacity style={styles.photoWrapper} onPress={handleChangePress}>
        {/* If user has added profile photo... */}
        {hasPhoto ? (
          <Image
            style={styles.photoCircle}
            resizeMode="cover"
            source={{ uri: photoState.uri }}
          />
        ) : (
          <View style={styles.photoEmptyView}>
            <Text style={styles.photoText}>ADD PHOTO</Text>
          </View>
        )}
      </TouchableOpacity>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.box}>
        <Text style={styles.exploreText}>Profile Page Note</Text>
        <View style={styles.separator} />
        <Text style={styles.descriptionText}>
          You have to enter your username before participating in a project!
          Wish you a happy journey!
        </Text>
      </View>
      <View style={styles.container}>
        <Photo />
        <TextInput
          style={styles.usernameInput}
          placeholder="Please enter your username."
          value={username}
          onChangeText={setUsername}
        />
      </View>
    </SafeAreaView>
  );
}

// Color generated from https://www.realtimecolors.com/?colors=0c1c0e-f2f9f2-709585-adb7c3-979bb2&fonts=Inter-Inter
const colors = {
  text: "#0b0e0d",
  background: "#fbfcfc",
  primary: "#709585",
  secondary: "#adb7c3",
  accent: "#979bb2",
};

// Define the styles for the components
const styles = {
  safeArea: {
    paddingHorizontal: 20,
  },
  container: {
    padding: 20,
    alignItems: "center",
  },
  photoWrapper: {
    marginBottom: 20,
    alignItems: "center",
  },
  photoEmptyView: {
    width: width * 0.3,
    height: width * 0.3,
    backgroundColor: "#709585",
    borderRadius: width * 0.25,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
  },
  photoCircle: {
    width: width * 0.3,
    height: width * 0.3,
    borderRadius: width * 0.25,
  },
  photoText: {
    color: "#0b0e0d",
    textAlign: "center",
    fontSize: 20,
  },
  usernameInput: {
    width: "100%",
    padding: 10,
    borderWidth: 3,
    borderColor: "#adb7c3",
    borderRadius: 5,
    fontSize: 16,
    marginBottom: 20,
  },
  box: {
    backgroundColor: colors.secondary,
    padding: 20,
    borderRadius: 10,
    marginVertical: 20,
    width: "100%",
    alignItems: "center",
  },
  exploreText: {
    fontSize: 18,
    fontWeight: "bold",
    color: colors.text,
    textAlign: "center",
    marginBottom: 10,
  },
  separator: {
    height: 1,
    backgroundColor: colors.accent,
    width: "90%",
    marginVertical: 10,
  },
  descriptionText: {
    fontSize: 16,
    color: colors.text,
    textAlign: "center",
  },
};
