// ProjectDetailPage.jsx

import React from "react";
import TabNavigator from "../navigation/TabNavigator";

export default function ProjectDetailPage({ route }) {
  return <TabNavigator route={route} />;
}