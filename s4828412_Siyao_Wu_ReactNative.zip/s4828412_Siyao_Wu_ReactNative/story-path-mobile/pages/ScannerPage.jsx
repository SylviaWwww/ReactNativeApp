// Code structure referenced from contact week 12
import React, { useState, useEffect, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  Button,
  ActivityIndicator,
} from "react-native";
import { CameraView, useCameraPermissions } from "expo-camera";

import { getLocationsByProject } from "../api/ProjectApi";
import { addTrackingRecord } from "../api/TrackingApi";

import { UsernameContext } from "../components/UsernameContext";
import { ProjectTrackingContext } from "../components/ProjectTrackingContext";

export default function AboutPage({ route, navigation }) {
  const { projectId } = route.params;
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");
  const [locations, setLocations] = useState(null);

  const [scanned, setScanned] = useState(false);
  const [scannedData, setScannedData] = useState("");
  const [permission, requestPermission] = useCameraPermissions();

  const { username } = useContext(UsernameContext);
  const {
    visitedLocations,
    setVisitedLocations,
    totalPoints,
    setTotalPoints,
    setTriggeredLocation,
  } = useContext(ProjectTrackingContext);

  useEffect(() => {
    (async () => {
      if (!permission || permission.status !== "granted") {
        const { status } = await requestPermission();
        if (status !== "granted") {
          alert("Camera permission is required to scan QR codes.");
          navigation.goBack();
          return;
        }
      }

      try {
        const locationsData = await getLocationsByProject(projectId);
        setLocations(locationsData);
      } catch (error) {
        alert(`Error fetching locations: ${error.message}`);
      } finally {
        setLoading(false);
      }
    })();
  }, [projectId, permission]);

  const handleBarCodeScanned = async ({ type, data }) => {
    setScanned(true);

    // Parse the scanned data
    let scannedData;
    try {
      scannedData = JSON.parse(data);
    } catch (error) {
      alert("Invalid QR code data.");
      setScanned(false);
      return;
    }

    const { id: scannedLocationId } = scannedData;

    // Find the location corresponding to the scanned location id
    const scannedLocation = locations.find(
      (location) =>
        location.id === scannedLocationId &&
        (location.location_trigger === "QR Code" ||
          location.location_trigger === "Both")
    );

    // Scanner Pgae logic is helped with chatgpt
    if (scannedLocation) {
      if (!visitedLocations.includes(scannedLocation.id)) {
        // New location, add tracking record
        try {
          await addTrackingRecord(
            projectId,
            scannedLocation.id,
            scannedLocation.score_points,
            username
          );
          // Update visitedLocations and totalPoints
          setVisitedLocations((prev) => [...prev, scannedLocation.id]);
          setTotalPoints((prev) => prev + scannedLocation.score_points);
        } catch (error) {
          console.error("Error adding tracking record:", error);
        }
      }
      // Set triggeredLocation to display in ProjectHome
      setTriggeredLocation(scannedLocation);
      alert(`You have unlocked ${scannedLocation.location_name}!`);
      navigation.goBack();
    } else {
      alert('QR Code not recognized for this project.');
      setErrorMessage("QR Code not recognized for this project.");
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  if (!permission) {
    // Camera permissions are still loading
    return (
      <View style={styles.container}>
        <Text>Requesting permissions...</Text>
      </View>
    );
  }

  if (!permission.granted) {
    // Camera permissions are not granted yet
    return (
      <View style={styles.container}>
        <Text style={styles.message}>
          We need your permission to show the camera
        </Text>
        <Button onPress={requestPermission} title="Grant permission" />
      </View>
    );
  }

  if (permission.status !== "granted") {
    return (
      <View style={styles.loadingContainer}>
        <Text>No access to camera.</Text>
        <Button onPress={requestPermission} title="Grant permission" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <CameraView
        style={styles.camera}
        type="front"
        onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
      >
        {scanned && (
          <View style={styles.scanResultContainer}>
            <Text style={styles.scanResultText}>
              Scanned data: {scannedData}
            </Text>
            <Button
              title="Tap to Scan Again"
              onPress={() => setScanned(false)}
            />
          </View>
        )}
      </CameraView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  camera: {
    flex: 1,
  },
  scanResultContainer: {
    position: "absolute",
    bottom: 50,
    left: "10%",
    right: "10%",
    backgroundColor: "rgba(0,0,0,0.7)",
    padding: 15,
    borderRadius: 8,
    alignItems: "center",
  },
  scanResultText: {
    color: "#fff",
    fontSize: 18,
    marginBottom: 10,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});
