import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";

const AboutPage = () => {
  return (
      <View style={styles.container}>
        <Text style={styles.title}>Welcome to Story Path!</Text>
        <Text style={styles.subtitle}>
          If you find some bugs, please ignore those mistakes~
        </Text>
      </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f0f0f0",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    textAlign: "center",
    marginBottom: 20,
  },
});

export default AboutPage;
