// Code structure referenced from contact week 11
import React, { useState, useEffect, useContext, useRef } from "react";
import {
  StyleSheet,
  Appearance,
  View,
  SafeAreaView,
  Text,
  ActivityIndicator,
} from "react-native";
import MapView, { Circle } from "react-native-maps";
import * as Location from "expo-location";
import { getDistance } from "geolib";

import { getLocationsByProject } from "../api/ProjectApi";
import { getUserTracking, addTrackingRecord } from "../api/TrackingApi";

import { UsernameContext } from "../components/UsernameContext";
import { ProjectTrackingContext } from "../components/ProjectTrackingContext";

const colorScheme = Appearance.getColorScheme();

export default function MapPage({ route }) {
  const { projectId } = route.params;
  const [locations, setLocations] = useState(null);
  const [loading, setLoading] = useState(true);

  // Get Username and Tracking Data through UseContext
  const { username } = useContext(UsernameContext);
  const {
    visitedLocations,
    setVisitedLocations,
    totalPoints,
    setTotalPoints,
    triggeredLocation,
    setTriggeredLocation,
  } = useContext(ProjectTrackingContext);

  // Keep track of locations triggered in the current session
  const triggeredLocationsRef = useRef(new Set());

  // Initialize mapState with default values
  const [mapState, setMapState] = useState({
    locationPermission: false,
    locations: [],
    userLocation: {
      latitude: -27.5263381,
      longitude: 153.0954163,
    },
  });

  // Fetch locations
  useEffect(() => {
    async function fetchLocations() {
      try {
        const locationsData = await getLocationsByProject(projectId);
        setLocations(locationsData);
      } catch (error) {
        alert(`Error fetching locations: ${error.message}`);
      } finally {
        setLoading(false);
      }
    }

    fetchLocations();
  }, [projectId]);

  // Fetch user's tracking data
  useEffect(() => {
    async function fetchUserTracking() {
      try {
        const trackingData = await getUserTracking(projectId, username);
        // number of visited location
        const visitedLocationIds = trackingData.map(
          (record) => record.location_id
        );
        // number of points
        const totalPointsEarned = trackingData.reduce(
          (sum, record) => sum + record.points,
          0
        );
        setVisitedLocations(visitedLocationIds);
        setTotalPoints(totalPointsEarned);
      } catch (error) {
        console.error("Error fetching user tracking data:", error);
      }
    }

    fetchUserTracking();
  }, [projectId, username]);

  // Update mapState.locations when locations change
  useEffect(() => {
    if (locations) {
      const updatedLocations = locations.map((location) => {
        const latlong = location.location_position
          .replace(/[()]/g, "")
          .split(",");
        location.coordinates = {
          latitude: parseFloat(latlong[0]),
          longitude: parseFloat(latlong[1]),
        };
        return location;
      });

      setMapState((prevState) => ({
        ...prevState,
        locations: updatedLocations,
      }));
    }
  }, [locations]);

  // Request location permission
  useEffect(() => {
    async function requestLocationPermission() {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === "granted") {
        setMapState((prevState) => ({
          ...prevState,
          locationPermission: true,
        }));
      }
    }
    requestLocationPermission();
  }, []);

  // Watch user location
  useEffect(() => {
    function calculateDistance(userLocation) {
      const nearbyLocations = mapState.locations
        .filter(
          (location) =>
            // Only works when triffer is "Location" or "Both"
            (location.location_trigger === "Location" ||
              location.location_trigger === "Both") &&
            !visitedLocations.includes(location.id)
        )
        .map((location) => {
          const metres = getDistance(userLocation, location.coordinates);
          location["distance"] = {
            metres: metres,
            nearby: metres <= 100,
          };
          return location;
        })
        .filter((location) => location.distance.nearby);

      return nearbyLocations;
    }

    let locationSubscription = null;

    if (mapState.locationPermission) {
      (async () => {
        locationSubscription = await Location.watchPositionAsync(
          {
            accuracy: Location.Accuracy.High,
            distanceInterval: 10,
          },
          async (location) => {
            const userLocation = {
              latitude: location.coords.latitude,
              longitude: location.coords.longitude,
            };
            const nearbyLocations = calculateDistance(userLocation);

            for (const nearbyLocation of nearbyLocations) {
              if (!triggeredLocationsRef.current.has(nearbyLocation.id)) {
                triggeredLocationsRef.current.add(nearbyLocation.id);

                // Trigger location if location_trigger is "Location" or "Both"
                if (
                  nearbyLocation.location_trigger === "Location" ||
                  nearbyLocation.location_trigger === "Both"
                ) {
                  if (!visitedLocations.includes(nearbyLocation.id)) {
                    // New location, add tracking record
                    try {
                      await addTrackingRecord(
                        projectId,
                        nearbyLocation.id,
                        nearbyLocation.score_points,
                        username
                      );
                      // Update visitedLocations and totalPoints
                      setVisitedLocations((prev) => [
                        ...prev,
                        nearbyLocation.id,
                      ]);
                      setTotalPoints(
                        (prev) => prev + nearbyLocation.score_points
                      );
                    } catch (error) {
                      console.error("Error adding tracking record:", error);
                    }
                  }
                  // Set triggeredLocation to display in ProjectHome
                  setTriggeredLocation(nearbyLocation);
                }
              }
            }

            setMapState((prevState) => ({
              ...prevState,
              userLocation,
            }));
          }
        );
      })();
    }

    // Cleanup function
    return () => {
      if (locationSubscription) {
        locationSubscription.remove();
      }
    };
  }, [
    mapState.locationPermission,
    mapState.locations,
    visitedLocations,
    projectId,
    username,
    setVisitedLocations,
    setTotalPoints,
    setTriggeredLocation,
  ]);

  // Handle loading and error states
  if (loading) {
    return (
      <SafeAreaView style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0000ff" />
      </SafeAreaView>
    );
  }

  if (!locations) {
    return (
      <SafeAreaView style={styles.loadingContainer}>
        <Text>Error loading locations.</Text>
      </SafeAreaView>
    );
  }

  return (
    <>
      <MapView
        camera={{
          center: mapState.userLocation,
          pitch: 0,
          heading: 0,
          altitude: 3000,
          zoom: 15,
        }}
        showsUserLocation={mapState.locationPermission}
        style={styles.container}
      >
        {mapState.locations.map((location) => (
          <Circle
            key={location.id}
            center={location.coordinates}
            radius={100}
            strokeWidth={3}
            strokeColor="#A42DE8"
            fillColor={
              colorScheme === "dark"
                ? "rgba(128,0,128,0.5)"
                : "rgba(210,169,210,0.5)"
            }
          />
        ))}
      </MapView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});
