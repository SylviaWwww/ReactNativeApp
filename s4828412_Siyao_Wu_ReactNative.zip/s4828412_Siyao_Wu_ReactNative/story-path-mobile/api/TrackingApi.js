// Code structure referenced from A2 sample code

// Base URL for the Storypath RESTful API
const API_BASE_URL = "https://0b5ff8b0.uqcloud.net/api";

// JWT token for authorization, replace with your actual token from My Grades in Blackboard
const JWT_TOKEN =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoic3R1ZGVudCIsInVzZXJuYW1lIjoiczQ4Mjg0MTIifQ.zAJnYyZIOsYasYpID7f9kZaJYMUe3hEnYdzr3-o9wqo";

// Your UQ student username, used for row-level security to retrieve your records
const USERNAME = "s4828412";

/**
 * Helper function to handle API requests.
 * It sets the Authorization token and optionally includes the request body.
 *
 * @param {string} endpoint - The API endpoint to call.
 * @param {string} [method='GET'] - The HTTP method to use (GET, POST, PATCH).
 * @param {object} [body=null] - The request body to send, typically for POST or PATCH.
 * @returns {Promise<object>} - The JSON response from the API.
 * @throws Will throw an error if the HTTP response is not OK.
 */
async function apiRequest(endpoint, method = "GET", body = null) {
  const options = {
    method, // Set the HTTP method (GET, POST, PATCH)
    headers: {
      "Content-Type": "application/json", // Indicate that we are sending JSON data
      Authorization: `Bearer ${JWT_TOKEN}`, // Include the JWT token for authentication
    },
  };

  // If the method is POST or PATCH, we want the response to include the full representation
  if (method === "POST" || method === "PATCH") {
    options.headers["Prefer"] = "return=representation";
  }

  // If a body is provided, add it to the request and include the username
  if (body) {
    options.body = JSON.stringify({ ...body, username: USERNAME });
  }

  // Make the API request and check if the response is OK
  const response = await fetch(`${API_BASE_URL}${endpoint}`, options);

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  // Return the response as a JSON object
  return response.json();
}

/**
 * Fetch the user's tracking data for a specific project.
 *
 * @param {number} projectId - The ID of the project.
 * @param {string} participant_username - The username of the participant.
 * @returns {Promise<Array>} - An array of tracking records.
 */
export async function getUserTracking(projectId, participant_username) {
  try {
    const endpoint = `/tracking?project_id=eq.${projectId}&participant_username=eq.${participant_username}`;
    const data = await apiRequest(endpoint, "GET");
    return data;
  } catch (error) {
    console.error("Error fetching user tracking:", error);
    throw error;
  }
}

/**
 * Add a tracking record when the user visits a new location.
 *
 * @param {number} projectId - The ID of the project.
 * @param {number} locationId - The ID of the location.
 * @param {number} points - The points earned at the location.
 * @param {string} participant_username - The username of the participant.
 * @returns {Promise<object>} - The created tracking record.
 */
export async function addTrackingRecord(
  projectId,
  locationId,
  points,
  participant_username
) {
  try {
    const data = {
      project_id: projectId,
      location_id: locationId,
      points: points,
      participant_username: participant_username,
    };
    const response = await apiRequest("/tracking", "POST", data);
    return response;
  } catch (error) {
    console.error("Error adding tracking record:", error);
    throw error;
  }
}

/**
 * Fetch the count of unique participants who have visited a location.
 *
 * @param {number} locationId - The ID of the location.
 * @returns {Promise<number>} - The count of unique participants.
 */
export async function getLocationParticipantsCount(locationId) {
  try {
    const endpoint = `/tracking?location_id=eq.${locationId}&select=participant_username`;
    const data = await apiRequest(endpoint, "GET");
    const uniqueParticipants = new Set(
      data.map((record) => record.participant_username)
    );
    return uniqueParticipants.size;
  } catch (error) {
    console.error("Error fetching location participants count:", error);
    throw error;
  }
}
