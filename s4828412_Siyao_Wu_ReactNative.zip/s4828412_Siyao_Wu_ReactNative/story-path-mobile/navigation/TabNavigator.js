// TabNavigator.js

import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import Feather from "react-native-vector-icons/Feather";

import ProjectHome from "../pages/ProjectHome";
import MapPage from "../pages/MapPage";
import ScannerPage from "../pages/ScannerPage";

import { UsernameContext } from "../components/UsernameContext";
import { ProjectTrackingProvider } from "../components/ProjectTrackingContext";

const Tab = createBottomTabNavigator();

const TabNavigator = ({ route }) => {
  return (
    <ProjectTrackingProvider projectId={route.params}>
      <Tab.Navigator
        initialRouteName="Project Home"
        screenOptions={{
          tabBarActiveTintColor: "#709585",
          tabBarInactiveTintColor: "gray",
          headerShown: false,
        }}
      >
        <Tab.Screen
          name="Project Home"
          component={ProjectHome}
          initialParams={route.params}
          options={{
            tabBarIcon: ({ color, size }) => (
              <Feather name="grid" size={size} color={color} />
            ),
          }}
        />
        <Tab.Screen
          name="Map"
          component={MapPage}
          initialParams={route.params}
          options={{
            tabBarIcon: ({ color, size }) => (
              <Feather name="map-pin" size={size} color={color} />
            ),
          }}
        />
        <Tab.Screen
          name="QR Code Scanner"
          component={ScannerPage}
          initialParams={route.params}
          options={{
            tabBarIcon: ({ color, size }) => (
              <Feather name="maximize" size={size} color={color} />
            ),
          }}
        />
      </Tab.Navigator>
    </ProjectTrackingProvider>
  );
};

export default TabNavigator;
