// AppNavigator.js

import React, { useState } from "react";
import { SafeAreaView } from "react-native";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { createStackNavigator } from "@react-navigation/stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { NavigationContainer } from "@react-navigation/native";
import Feather from "react-native-vector-icons/Feather";

import WelcomePage from "../pages/WelcomePage";
import ProfilePage from "../pages/ProfilePage";
import ProjectsPage from "../pages/ProjectsPage";
import ProjectDetailPage from "../pages/ProjectDetailPage";
import AboutPage from "../pages/AboutPage";
import MapPage from "../pages/MapPage";
import ScannerPage from "../pages/ScannerPage";

import { UsernameContext } from "../components/UsernameContext";
import CustomHeader from "../components/CustomHeader";
import CustomDrawerContent from "../components/CustomDrawerContent";
import { ProjectTrackingProvider } from "../components/ProjectTrackingContext";

const Drawer = createDrawerNavigator(); // Drawer navigation, a menu that can slide out from the side
const Stack = createStackNavigator(); // Stack navigation, used for forward and backward pages
const Tab = createBottomTabNavigator();

// Color generated from https://www.realtimecolors.com/?colors=0c1c0e-f2f9f2-709585-adb7c3-979bb2&fonts=Inter-Inter
const colors = {
  text: "#0b0e0d",
  background: "#fbfcfc",
  primary: "#709585",
  secondary: "#adb7c3",
  accent: "#979bb2",
};

function ProjectsStack() {
  return (
    // Used to go backward Project List Page
    <Stack.Navigator>
      <Stack.Screen
        name="Projects"
        component={ProjectsPage}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="ProjectHome"
        component={ProjectDetailPage}
        options={{ title: "Project Detail" }}
      />
    </Stack.Navigator>
  );
}

const AppNavigator = () => {
  const [username, setUsername] = useState("");

  return (
    //  Context provider wraps the entire navigation
    <UsernameContext.Provider value={{ username, setUsername }}>
      {/* Use Context to share username state across the navigation system */}
      <NavigationContainer>
        <Drawer.Navigator
          initialRouteName="Welcome"
          screenOptions={{
            header: (props) => <CustomHeader {...props} />, // Passing information to CustomDrawerContent
            // This style usage is generated from chatgpt
            drawerActiveTintColor: colors.primary,
            drawerInactiveTintColor: colors.text,
            drawerLabelStyle: {
              fontSize: 16,
            },
            drawerStyle: {
              backgroundColor: colors.background,
            },
          }}
          // Passing information to CustomDrawerContent
          drawerContent={(props) => <CustomDrawerContent {...props} />}
        >
          {/* Four different pages */}
          <Drawer.Screen
            name="Welcome"
            component={WelcomePage}
            options={{
              drawerLabel: "Welcome",
              title: "Welcome",
              drawerIcon: ({ color, size }) => (
                <Feather name="home" color={color} size={size} />
              ),
            }}
          />
          <Drawer.Screen
            name="Profile"
            component={ProfilePage}
            options={{
              drawerLabel: "Profile",
              title: "Profile",
              drawerIcon: ({ color, size }) => (
                <Feather name="user" color={color} size={size} />
              ),
            }}
          />
          <Drawer.Screen
            name="ProjectsStack"
            component={ProjectsStack}
            options={{
              drawerLabel: "Projects",
              title: "Projects",
              drawerIcon: ({ color, size }) => (
                <Feather name="award" color={color} size={size} />
              ),
            }}
          />
          <Drawer.Screen
            name="About"
            component={AboutPage}
            options={{
              drawerLabel: "About",
              title: "About",
              drawerIcon: ({ color, size }) => (
                <Feather name="help-circle" color={color} size={size} />
              ),
            }}
          />
        </Drawer.Navigator>
      </NavigationContainer>
    </UsernameContext.Provider>
  );
};

export default AppNavigator;
