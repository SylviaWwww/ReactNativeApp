# Project Overview

This project uses several components that have been implemented with the help of GenAI (ChatGPT o1-preview) to understand how certain libraries, such as `react-native-svg`, `react-qr-code`, and `react-quill`, work and are integrated into a React application.

## Components

### 1. SVG Usage

These components integrate the `react-native-svg` library to render scalable vector graphics (SVGs) within the application. This allows for high-quality images and icons that scale appropriately across different device resolutions.

**Files:**

- `CustomDrawerContent.jsx`, `CustomHeader.jsx`, `WelcomePage.jsx`

GPT was used to assist with the integration and usage of SVG images within the application.

### 2. ProjectTrackingContext Provider

This component implements the Context API to manage and share state across the application regarding project tracking, such as visited locations and accumulated points.

**Files:**

- `ProjectTrackingContext.jsx`

GPT helped with the improvements of the `ProjectTrackingContext` using React's Context API.

### 3. AutoHeightWebView

This component utilizes the `react-native-autoheight-webview` library to display HTML content that automatically adjusts its height based on the content, ensuring proper rendering within the app's layout.

**Files:**

- `ProjectHome.jsx`

GPT provided suggestions on implementing the `AutoHeightWebView` component to handle dynamic content sizes within the app based on `react-native-webview` library.

### 4. QR Code Scanning Implementation

This component integrates the `expo-camera` library to enable QR code scanning functionality within the app. Users can scan QR codes to unlock content or trigger specific actions based on the scanned data.

**Files:**

- `ScannerPage.jsx`

GPT was used to improve the usage of the QR code scanning functionality using `expo-camera`.